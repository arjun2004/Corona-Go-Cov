#! /bin/sh
cd dist/
java -jar MyApp.jar